#include <bits/stdc++.h>
using namespace std;

class Solution{
    public:
	int spanningTree(int N, vector<pair<int, int>> adj[]){
		int parent[N], key[N], mstSet[N], sum = 0; 
    
        for (int i = 0; i < N; i++){
            key[i] = INT_MAX, mstSet[i] = false; 
        }
        
        priority_queue< pair<int,int>, vector <pair<int,int>> , greater<pair<int,int>> > pq;

        key[0] = 0; 
        parent[0] = -1; 
        pq.push({0, 0});

        while(!pq.empty()){ 
            int u = pq.top().second;
            int cost = pq.top().first ;
            pq.pop(); 
            
            if(!mstSet[u]){
                mstSet[u] = true; 
                sum += cost ;
                
                for (auto it : adj[u]) {
                    int v = it.first;
                    int weight = it.second;
                    if (mstSet[v] == false && weight < key[v]) {
                        parent[v] = u;
                        key[v] = weight; 
                        pq.push({key[v], v});    
                    }
                } 
            }
        } 
        
        for (int i = 1; i < N; i++) 
            cout << parent[i] << " - " << i <<" \n";

        return sum ;
    }
};


int main() {

	int V = 5;
	vector<vector<int>> edges = {{0, 1, 2}, {0, 2, 1}, {1, 2, 1}, {2, 3, 2}, {3, 4, 1}, {4, 2, 2}};
	vector<pair<int, int>> adj[V];
	for (auto it : edges) {
		adj[it[0]].push_back({it[1], it[2]});
		adj[it[1]].push_back({it[0], it[2]});
	}

	Solution obj;
	int sum = obj.spanningTree(V, adj);
	cout << "Sum of all the edge weights: " << sum << endl;

	return 0;
}