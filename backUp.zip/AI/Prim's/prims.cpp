#include <iostream>
#include <vector>
#include <queue>

#define INF INT_MAX

struct Edge {
    int src;      // Source node
    int dest;     // Destination node
    int weight;   // Weight of the edge

    Edge(int s, int d, int w) : src(s), dest(d), weight(w) {}
};

// Structure to represent a node (vertex) in the graph
struct Node {
    int id;            // Node ID
    bool visited;      // Flag to track visited nodes
    std::vector<Edge> edges;  // Edges (adjacent nodes) and corresponding edge weights

    Node(int i) : id(i), visited(false) {}
};

// Function to compare edges by weight for priority queue
struct CompareEdges {
    bool operator()(const Edge& e1, const Edge& e2) {
        return e1.weight > e2.weight;
    }
};

// Function to construct the Minimum Spanning Tree using Prim's algorithm
void primMST(const std::vector<Node>& graph) {
    int n = graph.size();  // Number of nodes
    std::vector<bool> visited(n, false);  // Array to track visited nodes
    std::priority_queue<Edge, std::vector<Edge>, CompareEdges> pq;  // Priority queue for selecting the minimum weight edge

    // Start with the first node
    visited[0] = true;

    // Add the edges of the first node to the priority queue
    for (const Edge& edge : graph[0].edges) {
        pq.push(edge);
    }

    while (!pq.empty()) {
        Edge currentEdge = pq.top();
        pq.pop();

        int src = currentEdge.src;
        int dest = currentEdge.dest;
        int weight = currentEdge.weight;

        // If the destination node is not visited, include the edge in the MST
        if (!visited[dest]) {
            std::cout << "Edge: " << src << " - " << dest << " | Weight: " << weight << std::endl;

            // Mark the destination node as visited
            visited[dest] = true;

            // Add the edges of the destination node to the priority queue
            for (const Edge& edge : graph[dest].edges) {
                pq.push(edge);
            }
        }
    }
}

int main() {
    // Create the graph
    std::vector<Node> graph(7);

    // Add the edges with their weights
    graph[0].edges.push_back(Edge(0, 1, 4));
    graph[0].edges.push_back(Edge(0, 2, 8));
    graph[1].edges.push_back(Edge(1, 2, 2));
    graph[1].edges.push_back(Edge(1, 3, 5));
    graph[2].edges.push_back(Edge(2, 3, 5));
    graph[2].edges.push_back(Edge(2, 4, 9));
    graph[3].edges.push_back(Edge(3, 4, 1));
    graph[3].edges.push_back(Edge(3, 5, 3));
    graph[4].edges.push_back(Edge(4, 5, 2));
    graph[4].edges.push_back(Edge(4, 6, 6));
    graph[5].edges.push_back(Edge(5, 6, 3));

    // Find the Minimum Spanning Tree using Prim's algorithm
    primMST(graph);

    return 0;
}

// In this program, we have an Edge structure to represent an edge in the graph. Each edge has a source node, a destination node, and a weight.

// We also have a Node structure to represent a node (vertex) in the graph. Each node has an ID, a visited flag to track visited nodes, and a vector of edges with their corresponding weights.

// The CompareEdges struct is used to compare edges by weight in order to prioritize the minimum weight edge in the priority queue.

// The primMST function implements Prim's algorithm to construct the Minimum Spanning Tree. It takes the graph as input and performs the following steps:

// Initialize an array to track visited nodes and a priority queue for selecting the minimum weight edge.
// Start with the first node by marking it as visited and adding its edges to the priority queue.
// While the priority queue is not empty, remove the edge with the minimum weight from the queue.
// If the destination node of the edge is not visited, include the edge in the MST, mark the destination node as visited, and add its edges to the priority queue.
// Repeat steps 3 and 4 until the priority queue is empty.
// In the main function, we create the graph by adding nodes and their edges with corresponding weights. You can modify this part of the code to create your own graph. Then, we call the primMST function with the graph to construct the Minimum Spanning Tree. Finally, we print the edges and their weights that form the Minimum Spanning Tree.