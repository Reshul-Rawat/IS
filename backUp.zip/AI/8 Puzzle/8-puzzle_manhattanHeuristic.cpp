#include <iostream>
#include <vector>
#include <queue>
#include <unordered_set>
using namespace std;

// Structure to represent a state of the puzzle
struct PuzzleState {
    vector<vector<int>> board;  // 2D vector to represent the puzzle board
    int cost;  // Cost of reaching this state from the initial state
    int heuristic;  // Heuristic value (Manhattan Distance)
    int totalCost;  // Total cost (cost + heuristic)
    vector<PuzzleState*> path;  // Path from the initial state to this state

    PuzzleState(const vector<vector<int>>& b, int c, int h) : board(b), cost(c), heuristic(h), totalCost(c + h) {}
};

// Function to check if two puzzle states are equal
bool isEqual(const vector<vector<int>>& state1, const vector<vector<int>>& state2) {
    for (int i = 0; i < state1.size(); ++i) {
        for (int j = 0; j < state1[i].size(); ++j) {
            if (state1[i][j] != state2[i][j]) {
                return false;
            }
        }
    }
    return true;
}

// Function to calculate the Manhattan Distance between two positions (x1, y1) and (x2, y2)
int manhattanDistance(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// Function to calculate the heuristic value (Manhattan Distance) for a puzzle state
int calculateHeuristic(const vector<vector<int>>& state) {
    int heuristic = 0;
    int n = state.size();

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int value = state[i][j];
            if (value != 0) {
                int targetRow = (value - 1) / n;
                int targetCol = (value - 1) % n;
                heuristic += manhattanDistance(i, j, targetRow, targetCol);
            }
        }
    }

    return heuristic;
}

// Function to generate the successor states of a puzzle state
vector<PuzzleState*> generateSuccessors(PuzzleState* state) {
    vector<PuzzleState*> successors;
    int n = state->board.size();

    int dx[] = {-1, 0, 1, 0};  // Possible movements: up, right, down, left
    int dy[] = {0, 1, 0, -1};

    int xBlank, yBlank;

    // Find the position of the blank space (0)
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (state->board[i][j] == 0) {
                xBlank = i;
                yBlank = j;
                break;
            }
        }
    }

    // Generate successor states by moving the blank space in each possible direction
    for (int i = 0; i < 4; ++i) {
        int xNew = xBlank + dx[i];
        int yNew = yBlank + dy[i];

        if (xNew >= 0 && xNew < n && yNew >= 0 && yNew < n) {
            vector<vector<int>> newBoard = state->board;
            swap(newBoard[xBlank][yBlank], newBoard[xNew][yNew]);
            PuzzleState* newState = new PuzzleState(newBoard, state->cost + 1, calculateHeuristic(newBoard));
            successors.push_back(newState);
        }
    }

    return successors;
}

// Function to compare two puzzle states based on their total cost (cost + heuristic)
struct ComparePuzzleState {
    bool operator()(const PuzzleState* state1, const PuzzleState* state2) {
        return state1->totalCost > state2->totalCost;
    }
};

// Function to solve the 8-puzzle problem using the A* algorithm with Manhattan Distance heuristic
void solve8Puzzle(const vector<vector<int>>& initialBoard) {
    int n = initialBoard.size();
    PuzzleState* initialState = new PuzzleState(initialBoard, 0, calculateHeuristic(initialBoard));

    priority_queue<PuzzleState*, vector<PuzzleState*>, ComparePuzzleState> pq;
    pq.push(initialState);

    unordered_set<string> visited;

    while (!pq.empty()) {
        PuzzleState* currentState = pq.top();
        pq.pop();

        visited.insert(string(currentState->board.begin(), currentState->board.end()));

        if (currentState->heuristic == 0) {
            // Solution found
            cout << "Solution found!\n";
            cout << "Total moves: " << currentState->cost << endl;
            cout << "Path: ";
            for (const auto& state : currentState->path) {
                cout << endl;
                for (const auto& row : state->board) {
                    for (const auto& value : row) {
                        cout << value << " ";
                    }
                    cout << endl;
                }
                cout << " | ";
            }
            cout << endl;
            return;
        }

        vector<PuzzleState*> successors = generateSuccessors(currentState);
        for (PuzzleState* successor : successors) {
            if (visited.find(string(successor->board.begin(), successor->board.end())) == visited.end()) {
                successor->path = currentState->path;
                successor->path.push_back(currentState);
                pq.push(successor);
            } else {
                delete successor;
            }
        }
    }

    // No solution found
    cout << "No solution found.\n";
}

int main() {
    vector<vector<int>> initialBoard = {
        {1, 2, 3},
        {4, 0, 5},
        {7, 8, 6}
    };

    solve8Puzzle(initialBoard);

    return 0;
}


// In this program, the PuzzleState structure represents a state of the puzzle. It contains the puzzle board configuration (board), the cost of reaching this state from the initial state (cost), the heuristic value (Manhattan Distance) (heuristic), the total cost (totalCost), and the path from the initial state to this state (path).

// The isEqual function checks if two puzzle states are equal by comparing the board configurations.

// The manhattanDistance function calculates the Manhattan Distance between two positions (x1, y1) and (x2, y2).

// The calculateHeuristic function calculates the heuristic value (Manhattan Distance) for a puzzle state by iterating over the board and sum