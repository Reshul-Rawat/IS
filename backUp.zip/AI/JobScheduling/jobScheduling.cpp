#include<bits/stdc++.h>

using namespace std;

struct Job {
    int id; 
    int deadline;
    int profit; 
};
class Solution {
    public:
    bool static comparison(Job a, Job b) {
        return (a.profit > b.profit);
    }
   //Function to find the maximum profit and the number of jobs done
    vector<int> JobScheduling(Job arr[], int n) {
        sort(arr, arr + n, comparison);
        int maxi = arr[0].deadline;
        for (int i = 1; i < n; i++) {
            maxi = max(maxi, arr[i].deadline);
        }

        vector<int> slot(maxi + 1);

        for (int i = 0; i <= maxi; i++)
            slot[i] = -1;

        int countJobs = 0, jobProfit = 0;

        for (int i = 0; i < n; i++) {
            for (int j = arr[i].deadline; j > 0; j--) {
                if (slot[j] == -1) {
                    slot[j] = arr[i].id;
                    countJobs++;
                    jobProfit += arr[i].profit;
                    break;
                }
            }
        }

        cout << "Jobs count: " << countJobs << "\n" ;
        cout << "Total Job Profit: " << jobProfit << "\n" ;

        return slot ;
    }
};
int main() {
    int n = 4;
    Job arr[n] = {{1,4,20},{2,1,10},{3,2,40},{4,2,30}};

    Solution ob;
    
    vector<int> ans = ob.JobScheduling(arr, n);

    cout << "\nJobs are scheduled as:\n" ;
    for(auto x : ans){
        cout << x << " " ;
    }
    // cout << ans.first << " " << ans.second << endl;

    return 0;
}