#include <bits/stdc++.h>
using namespace std;

class Solution {
  public:
    void bfsOfGraph(int V, vector<int> adj[], vector<int> &ans, vector<int> vis, queue<int> q) {
        if(q.empty()){
            return ;
        }

        int node = q.front() ;
        q.pop() ;
        ans.push_back(node) ;

        for(auto it : adj[node]){
            if(!vis[it]){
                vis[it] = 1 ;
                q.push(it) ;
            }
        }

        bfsOfGraph(V, adj, ans, vis, q) ;
    }
};

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        int V, E;
        cin >> V >> E;

        vector<int> adj[V];

        for (int i = 0; i < E; i++){
            int u, v;
            cin >> u >> v;
            adj[u].push_back(v);
        }

        Solution obj;
        vector<int> vis(V, 0) ;
        vis[0] = 1 ;
        queue<int> q ;
        q.push(0) ;
        vector<int> ans ;
        obj.bfsOfGraph(V, adj, ans, vis, q);
        for (int i = 0; i < ans.size(); i++) {
            cout << ans[i] << " ";
        }
        cout << endl;
    }
    return 0;
}