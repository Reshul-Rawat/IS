#include <bits/stdc++.h>
using namespace std;

class Solution{
    public:
    vector<int> shortestPath(int n, int m, vector<vector<int>> &edges){

        vector<pair<int, int>> adjList[n + 1] ;
        for (auto it : edges){
            adjList[it[0]].push_back({it[1], it[2]}) ;
            adjList[it[1]].push_back({it[0], it[2]}) ;
        }

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int,int>>> pq ;

        vector<int> dist(n + 1, INT_MAX), parent(n + 1) ;
        for (int i = 1; i <= n; i++){
            parent[i] = i ;
        }

        dist[1] = 0 ;

        pq.push({0, 1}) ;
        while (!pq.empty()){

            pair<int, int> it = pq.top();
            pq.pop();
            int node = it.second;
            int dis = it.first;

            for (auto it : adjList[node]){
                int adjNode = it.first;
                int edW = it.second;

                if (dis + edW < dist[adjNode]){
                    dist[adjNode] = dis + edW;
                    pq.push({dis + edW, adjNode});

                    parent[adjNode] = node;
                }
            }
        }

        if (dist[n] == INT_MAX) return {-1};

        vector<int> path;
        int node = n;

        while (parent[node] != node){
            path.push_back(node);
            node = parent[node];
        }
        path.push_back(1);
        reverse(path.begin(), path.end());
        
        return path;
    }
};

int main(){
    int v = 6, e = 8;
    vector<vector<int>> edges = {{1, 2, 2}, {1, 3, 4}, {2, 4, 7}, {2, 3, 1}, {3, 5, 5}, {5, 4, 2}, {5, 6, 5}, {4, 6, 1}};
    Solution obj;
    vector<int>path = obj.shortestPath(v, e, edges);

    for (int i = 0 ; i < path.size() ; i++){
        cout << path[i] << " ";
    }
    cout << "\n";
    
    return 0;
}