#include<bits/stdc++.h>
using namespace std;


int main(){
	string st;
	int key;
	int op;

	cout<<"enter the message : ";
	cin>>st;

	cout<<"\nMenu\n 1>and\n 2>xor\n 3>or \n";
	cin>>op;

	if(op == 1){
		for(int i=0; i<st.length();i++){
			st[i] = st[i] & 127;
		}
		cout<<endl<<st;
	}

	else if(op ==2){
		for(int i=0; i < st.length();i++){
			st[i] = st[i] ^ 127 ;
		}
		cout<<endl;

		for(int i=0; i<st.length();i++){
			st[i] =  st[i] ^ 127;
		}
		cout<<endl<<st;
	}

	else if(op == 3){
		for(int i=0; i < st.length();i++){
			st[i] = (st[i] | 127) ;
		}
		cout<<st;
	}

	return 0;
}
