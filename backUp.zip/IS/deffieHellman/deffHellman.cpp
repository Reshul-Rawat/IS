#include<bits/stdc++.h>
using namespace std;
long long int power(int a,int b,int c)
{
    if(b==1) return a;
    else return (((long long int)pow(a,b))%c);

}
int main()
{
    long long int p,g,a,b,x,y,ka,kb;
    p=23;
    g=5;
    a=4;
    b=3;
    x=power(g,a,p);
    y=power(g,b,p);
    ka=power(y,a,p);
    kb=power(x,b,p);
    cout<<ka<<endl<<kb;
    return 0;

}