import random

def generateP(p,q):
    n=p*q
    phi=(p-1)*(q-1)
    e=random.randrange(1,phi)
    gcd=lambda a,b: a if not b else gcd(b,a%b)
    while(gcd(e,phi)!=1):
        e=random.randrange(1,phi)
    d=pow(e,-1,phi)
    return((e,n),(d,n))

def encr(message,pkey):
    key,n=pkey
    cipher=[pow(ord(i),key,n)for i in message]
    return cipher

def decr(cipher,pkey):
    key,n=pkey
    message=[chr(pow(i,key,n))for i in cipher]
    return "".join(message)

p=61
q=53
public,private=generateP(p,q)
message="Reshul"
encrypted=encr(message,public)
print("Encrypted:")
print(encrypted)

decrypted=decr(encrypted,private)
print("Decrypted:")
print(decrypted)