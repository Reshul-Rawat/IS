import hashlib
x = input("enter your string : ")
output = hashlib.md5(x.encode())
print()
print(output.hexdigest())