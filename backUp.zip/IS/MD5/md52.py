import struct

def leftr(value,shift):
    return ((value<<shift)& 0xFFFFFFFF)|(value>>(32-shift))

def md5(message):
    a=0xA12C36E1
    b=0x634521EA
    c=0x24AE326F
    d=0x5F22A425

    message=bytearray(message,'utf-8')
    original_len=(8*len(message))&0xFFFFFFFFFFFFFFFF
    message.append(0x80)
    while len(message)%64 !=56:
        message.append(0)
    message+=struct.pack('<Q',original_len)

    for i in range(0,len(message),64):
        chunk=message[i:i+64]
        words=list(struct.unpack('<16I',chunk))
        a_temp = a
        b_temp = b
        c_temp = c
        d_temp = d

        for j in range(64):
            if j<16:
                f=(b&c)|(~b&d)
                g=j
            elif j<32:
                f=(b&d)|(~d&c)
                g=(5*j+1)%16
            elif j<48:
                f=b^c^d
                g=(3*j+5)%16
            else:
                f=c^(b|~d)
                g=(7*j)%16
            temp=d
            d=c
            c=b
            b=(b+leftr((a+f+words[g]) & 0xFFFFFFFF,[7,12,17,22][j//16]))& 0xFFFFFFFF
            a=temp
        a=(a+a_temp)& 0xFFFFFFFF
        b=(b+b_temp)& 0xFFFFFFFF
        c=(c+c_temp)& 0xFFFFFFFF
        d=(d+d_temp)& 0xFFFFFFFF
    return struct.pack('<4I',a,b,c,d).hex()

message="Ankush"
md5ha=md5(message)
print("hash",md5ha)